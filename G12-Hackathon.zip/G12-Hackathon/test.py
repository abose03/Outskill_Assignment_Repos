def greet(name):
    print("Hello", name)

greet("John")

import subprocess
try:
    ans = subprocess.check_output(["python", "--version"], text=True)
    print(ans)

except subprocess.CalledProcessError as e:
    print(f"Command failed with return code {e.returncode}")

import gradio as gr
'''
# Example implementation of a user query component with an arrow button
def process_query(query):
    return f"Processed: {query}"

with gr.Blocks() as demo:
    gr.Markdown("### Query Input")
    
    with gr.Row():
        # Input Textbox
        user_input = gr.Textbox(
            label="Enter Query",
            placeholder="Type here...",
            show_label=False,
            scale=4 # Takes up more space
        )
        # Arrow Button (using unicode)
        submit_btn = gr.Button("➡", variant="primary", scale=1)

    output = gr.Textbox(label="Result")

    # Connect components
    submit_btn.click(fn=process_query, inputs=user_input, outputs=output)
    # Also submit on Enter key
    user_input.submit(fn=process_query, inputs=user_input, outputs=output)

demo.launch()
'''

import gradio as gr
from gradio_rich_textbox import RichTextbox

def process_rich_text(text_input):
    # Your function receives the rich text as a string (e.g., "Hello [b]World[/b]")
    processed_text = f"Received: {len(text_input)} characters. Original: {text_input}"
    return processed_text

with gr.Blocks() as demo:
    # Use RichTextbox as an input component
    input_box = RichTextbox(label="Enter Rich Text (using BBCode)")
    output_box = gr.Textbox(label="Processed Output (plain text)")
    
    input_box.change(process_rich_text, inputs=input_box, outputs=output_box)

demo.launch()